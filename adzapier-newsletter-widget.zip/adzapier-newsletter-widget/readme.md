http://127.0.0.1:8080/
https://github.com/abhishekkhandait/Preact-Task-Board
https://cookiethough.dev/development/
https://github.com/mattcarlotta/cra-single-bundle/tree/master/config
https://github.com/inthepocket/cookie-though