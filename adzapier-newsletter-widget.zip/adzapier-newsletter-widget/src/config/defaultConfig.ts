

const defaultConfig ={
    type: "sidebar",
    display:true,
    backgrounColor:'rgb(12, 44, 91)',
    logoURl:"https://www.getadmiral.com/hubfs/Logo%20no%20bg.svg",
    body: 'For the Latest Admiral Announcements Follow us on Twitter!',
   
};


export default defaultConfig;