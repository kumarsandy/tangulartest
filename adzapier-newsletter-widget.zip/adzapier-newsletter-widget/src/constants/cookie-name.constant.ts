export const cookieName = {
    AzConsentPreference: 'az-consent-preference'
}
export const optStatus = {
    optIn: 'Opt-in',
    optOut: 'Opt-out'
}
