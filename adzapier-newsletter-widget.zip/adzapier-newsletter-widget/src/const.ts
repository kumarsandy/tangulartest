

export const containerModalClassName = "social-fortuna-modal-wrapper"
export const containerAffixClassName = "social-fortuna-affix-wrapper"


//  export default {
//     containerModalClassName,
//     containerAffixClassName
// }